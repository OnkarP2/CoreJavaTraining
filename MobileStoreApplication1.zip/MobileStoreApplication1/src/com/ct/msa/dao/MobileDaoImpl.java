package com.ct.msa.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ct.msa.model.Mobile;

public class MobileDaoImpl implements IMobileDAO{

	static ArrayList<Mobile> list=new ArrayList<Mobile>();
	
	public void addMobile(Mobile m) {
		list.add(m);
	}

	public void deleteMobile(int mId) {
		// TODO Auto-generated method stub
		Iterator<Mobile> itr= list.iterator();
		while(itr.hasNext())
		{
			Mobile m=itr.next();
			if(m.getId()==mId)
		{
			itr.remove();
		}
		}
	}

	
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		Iterator<Mobile> itr= list.iterator();
		while(itr.hasNext())
		{
			Mobile m=itr.next();
			if(m.getId()==mId)
			{
			System.out.println("Previous Details : "+m.getName() + m.getDescription() + m.getId() + m.getPrice());
			System.out.println("Enter the following data \n Name \n Description \n ID \n Price");
			m.setName(scn.next());
			m.setDescription(scn.nextLine());
			m.setId(scn.nextInt());
			m.setPrice(scn.nextInt());
			}
		}
	}

	@Override
	public Mobile searchMobileById(int mId) {
		// TODO Auto-generated method stub
		Mobile ms=new Mobile();
		Iterator<Mobile> itr= list.iterator();
		while(itr.hasNext())
		{
			Mobile m=itr.next();
			if(m.getId()==mId)
			{
				ms=m;
			}
			
		}
		return ms;
	}

	@Override
	public ArrayList<Mobile> displayAllMobiles() {
		// TODO Auto-generated method stub
		
		ArrayList<Mobile> m1= new ArrayList<Mobile>();
		Iterator<Mobile> itr= list.iterator();
		while(itr.hasNext())
		{
		//	Mobile m=itr.next();
			//System.out.println(m.getName() + m.getDescription() + m.getId() + m.getPrice());
		m1.add( itr.next());
			
		}
		
		return m1;
	}

}

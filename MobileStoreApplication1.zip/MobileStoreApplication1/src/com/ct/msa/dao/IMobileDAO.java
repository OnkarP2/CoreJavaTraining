package com.ct.msa.dao;

import java.util.ArrayList;

import com.ct.msa.model.Mobile;

public interface IMobileDAO {

	public void addMobile(Mobile m);
	public void deleteMobile(int mId);
	public void updateMobileDetails(int mId);
	public Mobile searchMobileById(int mId);
	public ArrayList<Mobile> displayAllMobiles();
	
}

package com.ct.msa.service;

import java.util.ArrayList;

import com.ct.msa.dao.MobileDaoImpl;
import com.ct.msa.model.Mobile;

public class MobileServiceImpl implements IMobileService {

	@Override
	public void addMobile(Mobile m) {
		// TODO Auto-generated method stub
		new MobileDaoImpl().addMobile(m);
	}

	@Override
	public void deleteMobile(int mId) {
		// TODO Auto-generated method stub
	do {	
		new MobileDaoImpl().deleteMobile(mId);
	}while(mId>99 && mId<1000);
	}

	@Override
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		do {
		new MobileDaoImpl().updateMobileDetails(mId);
	}while(mId>99 && mId<1000);

	}

	@Override
	public Mobile searchMobileById(int mId) {
		// TODO Auto-generated method stub
		do {
		new MobileDaoImpl().searchMobileById(mId);
	}while(mId>99 && mId<1000);
		
	}

	@Override
	public ArrayList<Mobile> displayAllMobiles() {
		// TODO Auto-generated method stub
		ArrayList<Mobile> m1=new ArrayList<Mobile>();
		m1=new MobileDaoImpl().displayAllMobiles();
		return m1;
	}

}

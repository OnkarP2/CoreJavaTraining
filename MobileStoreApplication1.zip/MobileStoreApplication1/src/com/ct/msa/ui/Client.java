package com.ct.msa.ui;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.ct.msa.model.Mobile;
import com.ct.msa.service.MobileServiceImpl;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Mobile> al=new ArrayList<Mobile>();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your choice \n 1.Add mobile \n 2.Search Mobile by ID \n 3.Display All Mobiles \n 4.Delete Mobile \n 5.Update mobile  \n 6.Exit");
		int a=sc.nextInt();
		
		abc:switch (a)

		{
	
		case 1:
			System.out.println("Please enter the following details \n Mobile Name \n Description \n ID \n Price");
			String mn=sc.next();
			String d1=sc.nextLine();
			int id=sc.nextInt();
			int p1=sc.nextInt();
			Mobile m=new Mobile(mn,d1,id,p1);
			new MobileServiceImpl().addMobile(m);
			break;
		case 2:
			System.out.println("Enter the ID for the mobile that you want to search");
			int id1=sc.nextInt();
			new MobileServiceImpl().searchMobileById(id1);
			break;
		case 3:
			al=new MobileServiceImpl().displayAllMobiles();
			Iterator<Mobile> it = al.iterator();
			while(it.hasNext())
			{
				Mobile mb=it.next();
				System.out.println(mb.getName() + mb.getDescription() + mb.getId() + mb.getPrice());
			}
			break;
		case 4:
			System.out.println("Enter the ID for the mobile that you want to delete");
			int id3=sc.nextInt();
			new MobileServiceImpl().deleteMobile(id3);
			
			break;
		case 5:
			System.out.println("Enter the ID for the device that you want to update");
			int id4=sc.nextInt();
			new MobileServiceImpl().updateMobileDetails(id4);
			break;
		case 6:
			System.exit(0);
		default:
			System.out.println("Enter correct");
			a=sc.nextInt();
			break abc;
		
		
		}
		}
	
	}

}

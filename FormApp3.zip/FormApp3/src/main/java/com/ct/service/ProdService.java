package com.ct.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ct.account.Login;
import com.ct.account.User;
import com.ct.dao.ProdDao;
import com.ct.model.Product;

@Service
public class ProdService {
	
	@Autowired
	private ProdDao dao;
	
	
	public String saveProduct(Product product)
	{
	return dao.saveProduct(product);
	}
	
	public Product viewProduct(int id)
	{
	return dao.viewProduct(id);
	}
	
	public String deleteProduct(int id)
	{
	return dao.deleteProduct(id);
	}
	/*public HashMap<Integer, Product> viewAllProduct()
	{
	return 
	}*/
	
	public List<Product> viewAllProducts()
	{
	return dao.viewAllProducts();
	}
	
	public Boolean login(Login login)
	{
	return dao.login(login);
	}
	
	public Boolean register(User user)
	{
	return dao.register(user);
	}
	
	public Boolean searchUsername(User user)
	{
	return dao.searchUsername(user);
	}
	
}

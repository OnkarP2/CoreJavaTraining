package com.ct.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.NamedQuery;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="formproduct")

public class Product {
	@Override
	public String toString() {
		return "Product [id=" + id + ", prodName=" + prodName + ", price=" + price + ", prodQty=" + prodQty
				+ ", description=" + description + ", discount=" + discount + "]";
	}
	@Id
	@GeneratedValue
	private int id;
	@Size(min=3, max=16,message="product name cannot be less than 3")
	private String prodName;
	@NotNull(message="field is mandatory")
	private float price;
	@NotNull(message="field is mandatory")
	private int prodQty;
	/*@NotNull(message="field is mandatory")*/
	@Size(min=3, max=16,message="product description cannot be less than 3")
	private String description;
	@NotNull(message="field is mandatory")
	private float discount;
	private String prodImage;
	public Product() {
	}
	public Product(String prodName, float price, int prodQty, String description, float discount) {
		super();
		this.prodName = prodName;
		this.price = price;
		this.prodQty = prodQty;
		this.description = description;
		this.discount = discount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getProdQty() {
		return prodQty;
	}
	public void setProdQty(int prodQty) {
		this.prodQty = prodQty;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getDiscount() {
		return discount;
	}
	public void setDiscount(float discount) {
		this.discount = discount;
	}
	public String getProdImage() {
		return prodImage;
	}
	public void setProdImage(String prodImage) {
		this.prodImage = prodImage;
	}
	
	
	
	
}

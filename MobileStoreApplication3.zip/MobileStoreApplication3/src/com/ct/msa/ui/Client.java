package com.ct.msa.ui;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;

import com.ct.msa.service.BookServiceImpl;
public class Client {

	
	static Logger log = Logger.getLogger(Client.class);
	static Scanner sc=new Scanner(System.in);
	static int rowModified=0;
	static boolean isAllowed=false;
	static int bSearch=0;
	static int userType;

	public static void main(String[] args) throws BookException {

		while(true)
		{
			
			ArrayList<Book> bookList=new ArrayList<Book>();
			Book btest=null;
			log.setLevel(Level.INFO);
			
		//Login interface
			try {
		System.out.println("Enter your choice \n 1. user \n 2. admin  \n 3. exit");
		userType=sc.nextInt();
			
		
		login:switch (userType)
		{
		//Login for Admin
		case 2:									

		try 
		{
			System.out.println("enter your username");
			String uName=sc.next();
			log.info("admin has entered name as " + uName);
			System.out.println("enter your password");
			String pwd=sc.next();
			log.info("admin has entered password as " + pwd);
			isAllowed=new BookServiceImpl().login(uName,pwd,userType);
		if(!isAllowed)
		{
			log.info("Wrong username or password is entered");
			System.out.println("Username or password not valid");
			break login;
		}
		}
		catch(BookException e)
		{
			log.error("error occured :: " + e.getMessage());
			System.out.println(e.getMessage());
		}
		
		log.info("Admin is logged in");
		//options for admin
		System.out.println("Enter your choice \n 1.Add Book \n 2.Search Book by ID \n 3.Display All Books \n 4.Delete Book   \n 5.Exit");
		int adminChoice=sc.nextInt();
		log.info("Admin entered choice as : "+adminChoice);
		switch (adminChoice)

		{
		
		//Adding a new book
		
		case 1:
		
			sc.nextLine();
			System.out.println("Please enter the following details \n Book Name ");
			String bookName=sc.nextLine();
			log.info("admin has entered name as " + bookName);
			System.out.println("Price");
			float bookPrice=sc.nextFloat();
			log.info("admin has entered price as " + bookPrice);
			sc.nextLine();
			System.out.println("Description");
			String bookDesc=sc.nextLine();
			log.info("admin has entered description as " + bookDesc);
			btest=new Book(bookName,bookDesc,bookPrice);
			
			log.info("Book is sent to service to add");
			try {
			rowModified=new BookServiceImpl().addBook(btest);
			if(rowModified==1){
			log.info("Book information added with name: "+bookName+" price: "+bookPrice+" Description: "+bookDesc);
			System.out.println("Data inserted in the database");}
			}
			catch(BookException e){
			log.error("error occured :: " + e.getMessage());
			System.out.println(e.getMessage());
			}
			
			break;
			
			//Search a book by id
		case 2:
			System.out.println("Enter the ID for the book that you want to search");
			bSearch=sc.nextInt();
			log.info("admin has entered id as " + bSearch);
			try {
			
			log.info("ID is sent to service to search");
			btest=new BookServiceImpl().searchBookById(bSearch);
			log.info("Book information found with id : " + bSearch);
			System.out.println(btest);
			log.info("Book found: "+btest);
			}
			catch(BookException e){
			log.error("error occured :: " + e.getMessage());
			System.out.println(e.getMessage());
			}
				
			break;
			//Display all the books in the database
		case 3:
			try {
			
			bookList=new BookServiceImpl().displayAllBooks();
			log.info("All Books information retrieved from db");
			Iterator<Book> it = bookList.iterator();
			while(it.hasNext())
			{
				btest=it.next();
				System.out.println(btest);
			}
			}
			catch(BookException e)
			{
				log.error("error occured :: " + e.getMessage());
				System.out.println(e.getMessage());
			}
			
			break;
			
			//Delete a book
		case 4:
			System.out.println("Enter the ID for the book that you want to delete");
			bSearch=sc.nextInt();
			log.info("admin has entered id as " + bSearch);
			log.info("ID is sent to service to delete");
			try {
			rowModified=new BookServiceImpl().deleteBook(bSearch);
			if (rowModified==1) {
			log.info("Book information found with id : " + bSearch+" and deleted");
			System.out.println("Book deleted from the database");}
			}
			catch(BookException e)
			{
				log.error("error occured :: " + e.getMessage());
				System.out.println(e.getMessage());
			}
			
			break;
			
			//stop the application
		case 5:
			System.exit(0);
		default:
			System.out.println("Enter a correct choice");
			break;
		
		}
		break;
		//Login for user
		case 1:									
			try {
				System.out.println("enter your username");
				String uName=sc.next();
				log.info("user has entered name as "+uName);
				System.out.println("enter your password");
				String pwd=sc.next();
				log.info("user has entered password as " + pwd);
			isAllowed=new BookServiceImpl().login(uName,pwd,userType);
			if(!isAllowed)
			{
				log.info("Wrong username or password is entered");
				System.out.println("Username not valid");
				break login;
				
			}
			}
			catch(BookException e)
			{
				log.error("error occured :: " + e.getMessage());
				System.out.println(e.getMessage());
				
			}
			
			log.info("user is logged in");
			//Display all the books to the user
			try {
				bookList=new BookServiceImpl().displayAllBooks();
				log.info("All Books information retrieved from db");
				Iterator<Book> it = bookList.iterator();
				while(it.hasNext())
				{
					btest=it.next();
					System.out.println(btest);
				}
				}
				catch(BookException e)
				{
					log.error("error occured :: " + e.getMessage());
					System.out.println(e.getMessage());
				}
				
				break;

				
				//stop the application
		case 3:
			System.exit(0);
		default:
			System.out.println("Enter a correct choice");
			break;
				
		}
		}
		 catch(InputMismatchException e)
			{
			 		log.error("input is wrong :: "+e.getMessage());
					System.out.println("Please enter a proper input");
				
			}
			sc.nextLine();
		}
	
	}





}

package com.ct.msa.ui;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;

import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;

import com.ct.msa.service.BookServiceImpl;
public class Client {

	public static void main(String[] args) throws BookException {
		// TODO Auto-generated method stub
		while(true)
		{
			ArrayList<Book> moblist=new ArrayList<Book>();
			Book mtest=null;
			Scanner sc=new Scanner(System.in);
			int qu=0;
			boolean ul=false;
			
			
			
		System.out.println("Enter your choice \n 1. user \n 2. admin  \n 3. exit");
		int lg=sc.nextInt();
		System.out.println("enter your username");
		String un=sc.next();
		System.out.println("enter your password");
		String pwd=sc.next();
		switch (lg)
		{
		case 2:

		try 
		{
		ul=new BookServiceImpl().login(un,pwd,lg);
		if(!ul)
		{
			System.out.println("Username not valid");
			break;
		}
		}
		catch(BookException e)
		{
			System.out.println(e.getMessage());
		}
		
		System.out.println("Enter your choice \n 1.Add Book \n 2.Search Book by ID \n 3.Display All Books \n 4.Delete Book   \n 5.Exit");
		int a=sc.nextInt();
		
		switch (a)

		{
	
		case 1:
			System.out.println("Please enter the following details \n Book Name ");
			String mn=sc.next();
			System.out.println("Price");
			float p1=sc.nextFloat();
			System.out.println("Description");
			String d1=sc.next();

			Book m=new Book(mn,d1,p1);
			try {
			qu=new BookServiceImpl().addBook(m);
			if(qu==1);
			System.out.println("Data inserted in the database");
			}
			catch(BookException e){
			System.out.println(e.getMessage());
			}
			
			break;
		case 2:
			System.out.println("Enter the ID for the mobile that you want to search");
			int id1=sc.nextInt();
			try {
			mtest=new BookServiceImpl().searchBookById(id1);
			System.out.println(mtest);
			}
			catch(BookException e){
			System.out.println(e.getMessage());
			}
				
			break;
		case 3:
			try {
			moblist=new BookServiceImpl().displayAllBooks();
			Iterator<Book> it = moblist.iterator();
			while(it.hasNext())
			{
				Book mb=it.next();
				System.out.println(mb);
			}
			}
			catch(BookException e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
		case 4:
			System.out.println("Enter the ID for the mobile that you want to delete");
			int id3=sc.nextInt();
			try {
			qu=new BookServiceImpl().deleteBook(id3);
			if (qu==1)
			System.out.println("Mobile deleted from the database");
			}
			catch(BookException e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
//		case 5:
//			System.out.println("Enter the ID for the device that you want to update");
//			int id4=sc.nextInt();
//			mtest=new MobileServiceImpl().searchMobileById(id4);
//			if(mtest==null)
//			{System.out.println("Enter a valid ID");}
//			else
//			{
//				
//				//new MobileServiceImpl().deleteMobile(id4);
//				
//				System.out.println("Please enter the updated details \n Mobile Name \n Description \n ID \n Price");
//				mtest.setName(sc.next());
//				mtest.setDescription(sc.next());
//				mtest.setId(sc.nextInt());
//				mtest.setPrice(sc.nextInt());
//				
//				/*mn=sc.next();
//				d1=sc.next();
//				id=sc.nextInt();
//				p1=sc.nextInt();
//				m=new Mobile(mn,d1,id,p1);
//				new MobileServiceImpl().addMobile(m);*/
//			}
//			break;
		case 5:
			System.exit(0);
		default:
			System.out.println("Enter a correct choice");
			break;
		
		}
		break;
		case 1:
			try {
			ul=new BookServiceImpl().login(un,pwd,lg);
			if(!ul)
			{
				System.out.println("Username not valid");
				
			}
			}
			catch(BookException e)
			{
				System.out.println(e.getMessage());
				
			}
			
			try {
				moblist=new BookServiceImpl().displayAllBooks();
				Iterator<Book> it = moblist.iterator();
				while(it.hasNext())
				{
					Book mb=it.next();
					System.out.println(mb);
				}
				}
				catch(BookException e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
			
		
			

			
			
			
			
		case 3:
			System.exit(0);
			default:
				System.out.println("Enter a correct choice");
				break;
				
		}
		}
	
	}





}

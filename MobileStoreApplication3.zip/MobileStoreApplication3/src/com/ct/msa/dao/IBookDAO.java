package com.ct.msa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;

public interface IBookDAO {

	public int addBook(Book m) throws BookException;
	public int deleteBook(int mId) throws BookException;
//	public void updateMobileDetails(int mId);
	public Book searchBookById(int mId) throws BookException;
	public ArrayList<Book> displayAllBooks() throws BookException;
	
}

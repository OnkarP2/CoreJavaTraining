package com.ct.msa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;
import com.ct.msa.util.DbUtil;
import com.ct.msa.util.IQueryMapper;

public class BookDaoImpl implements IBookDAO{

	static ArrayList<Book> list=new ArrayList<Book>();
	Book mu=null;
	Connection conn=null;
	ResultSet s=null;
	int qr;
	
	
	public int addBook(Book m) throws BookException {
	
		try
		{
		conn=DbUtil.getDbConnection();
		PreparedStatement st =conn.prepareStatement("INSERT INTO book VALUES (?,?,?)");
		st.setString(1, m.getName());
		st.setFloat(2,m.getPrice());
		st.setString(3, m.getDescription());
		qr=st.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new BookException("Connection established but data not added :"+e.getMessage());
		}
	
		return qr;
	}

	public int deleteBook(int mId) throws BookException {
		// TODO Auto-generated method stub
		try
		{
		conn=DbUtil.getDbConnection();
		PreparedStatement st =conn.prepareStatement(IQueryMapper.DELETE_BOOK);
		st.setInt(1, mId);
		qr=st.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new BookException("Connection established but data not deleted :"+e.getMessage());
		}
		return qr;
		
	}

	
	/*public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		
		mu=searchMobileById(mId);
		//if (mu)
		Scanner scn = new Scanner(System.in);
		Iterator<Mobile> itr= list.iterator();
		while(itr.hasNext())
		{
			Mobile m=itr.next();
			if(m.getId()==mId)
			{
			System.out.println("Previous Details : "+m.getName() + m.getDescription() + m.getId() + m.getPrice());
			System.out.println("Enter the following data \n Name \n Description \n ID \n Price");
			m.setName(scn.next());
			m.setDescription(scn.nextLine());
			m.setId(scn.nextInt());
			m.setPrice(scn.nextInt());
			}
		}
	}*/

	@Override
	public Book searchBookById(int mId) throws BookException {
		try 
		{
		conn=DbUtil.getDbConnection();
		PreparedStatement st =conn.prepareStatement(IQueryMapper.SEARCH_BOOK);
		st.setInt(1, mId);
		s=st.executeQuery();
		if(s.next()) {
			mu=new Book();
			//System.out.println(rs.getString(2));
			mu.setName(s.getString(1));
			mu.setId(s.getInt(2));
			mu.setPrice(s.getFloat(3));
			mu.setDescription(s.getString(4));
		}
		else
		{
			throw new BookException("Mobile not found");
		}
		return mu;
		}
		
		catch(SQLException e)
		{
			throw new BookException("Connection established but data not found :" +e.getMessage());
		}
		
	
	}

	@Override
	public ArrayList<Book> displayAllBooks() throws BookException {
		// TODO Auto-generated method stub
		try {
		conn=DbUtil.getDbConnection();
		PreparedStatement st =conn.prepareStatement(IQueryMapper.DISPLAY_ALL_BOOKS);
		//st.setInt(1, mId);
		s=st.executeQuery();
		
		while(s.next()) {
			mu=new Book();
		
			mu.setName(s.getString(1));
			mu.setId(s.getInt(2));
			mu.setPrice(s.getFloat(3));
			mu.setDescription(s.getString(4));
			list.add(mu);
		}
		return list;
		}
		catch(SQLException e)
		{
			throw new BookException("Connection established but data not displayed"+e.getMessage());
		}
		
		
		
		
		
	}

}

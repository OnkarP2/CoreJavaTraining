package com.ct.msa.dao;

import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Scanner;

import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;
import com.ct.msa.util.DbUtil;
import com.ct.msa.util.IQueryMapper;


public class BookDaoImpl implements IBookDAO{

	
	Book btest=null;
	Connection conn=null;
	ResultSet allBooks=null;
	int bookUpdated;
	static ArrayList<Book> bookList=new ArrayList<Book>();
	static Logger log=Logger.getLogger(BookDaoImpl.class);
	
	public int addBook(Book btest) throws BookException {
	
		try
		{
		conn=DbUtil.getDbConnection();  									//Establish a connection from DbUtil class 
		log.info("db is connected successfully "+conn);
		PreparedStatement st =conn.prepareStatement(IQueryMapper.ADD_BOOK);  //compile the statement
		log.info("qry is compiled and ready for placing values");
		st.setString(1, btest.getName());									//insert the data into the statement
		st.setFloat(2,btest.getPrice());
		st.setString(3, btest.getDescription());
		bookUpdated=st.executeUpdate();										//execute the statement
		log.info("qry is executed and");
		
		}
		catch(SQLException e)					//wrapping the exception to a user defined exception
		{
			log.error(e.getMessage());
			throw new BookException("Connection established but book not added  :"+e.getMessage());
		}
		log.info("data is ready "+bookUpdated);
		return bookUpdated;
	}

	public int deleteBook(int mId) throws BookException {
		try
		{
		conn=DbUtil.getDbConnection();											//Establish a connection from DbUtil class 
		log.info("db is connected successfully "+conn);
		PreparedStatement st =conn.prepareStatement(IQueryMapper.DELETE_BOOK);	//compile the statement
		log.info("qry is compiled and ready for placing values");
		st.setInt(1, mId);														//insert the data into the statement
		bookUpdated=st.executeUpdate();											//execute the statement
		log.info("qry is executed and");
		
		}
		catch(SQLException e)							//wrapping the exception to a user defined exception
		{
			log.error(e.getMessage());
			throw new BookException("Connection established but book not deleted :"+e.getMessage());
		}
		log.info("data is ready "+bookUpdated);
		return bookUpdated;
	}

	

	@Override
	public Book searchBookById(int mId) throws BookException {
		try 
		{
		conn=DbUtil.getDbConnection();											//Establish a connection from DbUtil class 
		log.info("db is connected successfully "+conn);
		PreparedStatement st =conn.prepareStatement(IQueryMapper.SEARCH_BOOK);	//compile the statement
		log.info("qry is compiled and ready for placing values");
		st.setInt(1, mId);														//insert the data into the statement
		allBooks=st.executeQuery();												//execute the statement
		log.info("qry is executed and");
		if(allBooks.next()) {
			btest=new Book();
			//System.out.println(rs.getString(2));
			btest.setName(allBooks.getString(2));
			btest.setId(allBooks.getInt(1));
			btest.setPrice(allBooks.getFloat(3));
			btest.setDescription(allBooks.getString(4));
		}
		else
		{
			throw new BookException("Currently no such book exists");		//throw an exception if book is not found instead of returning null to avoid NullPointerException
		}
		
		}
		
		catch(SQLException e)							//wrapping the exception to a user defined exception
		{
			log.error(e.getMessage());
			throw new BookException("Problem while fetching data from database .Contact admin :" +e.getMessage());
		}
		log.info("data is ready "+btest);
		return btest;
	
	}

	@Override
	public ArrayList<Book> displayAllBooks() throws BookException {
		try {
		conn=DbUtil.getDbConnection();
		log.info("db is connected successfully "+conn);
		PreparedStatement st =conn.prepareStatement(IQueryMapper.DISPLAY_ALL_BOOKS);
		log.info("qry is compiled and ready for placing values");
		allBooks=st.executeQuery();
		log.info("qry is executed and");
		bookList=new ArrayList<Book>();
		while(allBooks.next()) {
			btest=new Book();
			
			btest.setName(allBooks.getString(2));
			btest.setId(allBooks.getInt(1));
			btest.setPrice(allBooks.getFloat(3));
			btest.setDescription(allBooks.getString(4));
			bookList.add(btest);
		}
		
		}
		catch(SQLException e)
		{
			log.error(e.getMessage());
			throw new BookException("Problem while fetching data from database .Contact admin :"+e.getMessage());
		}
		
		
		log.info("data is ready "+bookList);
		return bookList;
		
	}

}

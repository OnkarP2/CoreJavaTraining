package com.ct.msa.exception;

public class BookException extends Exception{

	public BookException()
	{
		
	}
	
	public BookException(String s)
	{
		super(s);
	}
	
}

package com.ct.msa.util;


public interface IQueryMapper {
	public static final String ADD_BOOK="INSERT INTO book VALUES (?,?,?)";
	public static final String DELETE_BOOK="DELETE FROM book WHERE mId=?";
	public static final String SEARCH_BOOK="SELECT * FROM book WHERE mId=?";
	public static final String DISPLAY_ALL_BOOKS="SELECT * FROM book";
	
}

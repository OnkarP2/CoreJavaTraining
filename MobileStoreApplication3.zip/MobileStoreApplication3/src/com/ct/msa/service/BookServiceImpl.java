package com.ct.msa.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ct.msa.dao.BookDaoImpl;
import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;
import com.ct.msa.ui.Client;

public class BookServiceImpl implements IBookService {
	
	
	ArrayList<Book>bookList=new ArrayList<Book>();
	Book btest;
	boolean isAllowed=false;
	Properties prop=new Properties (); 
	String lin;
	static Logger log = Logger.getLogger(Client.class);
	
	@Override
	public int addBook(Book m) throws BookException{
		return new BookDaoImpl().addBook(m);

	
	}

	@Override
	public int deleteBook(int mId) throws BookException {

		return new BookDaoImpl().deleteBook(mId);
		
		

	}

	

	@Override
	public Book searchBookById(int mId) throws BookException {
		btest=new Book();
	
		btest=new BookDaoImpl().searchBookById(mId);
		
		return btest;
	}

	@Override
	public ArrayList<Book> displayAllBooks() throws BookException {

		bookList=new BookDaoImpl().displayAllBooks();
		return bookList;
	}

	public boolean login(String un,String pwd,int lg) throws BookException {
		try
		{
		
		if(lg==1)
		{lin="C:\\Users\\Trainingvdi\\Downloads\\MobileStoreApplication4\\MobileStoreApplication3\\MobileStoreApplication3\\src\\com\\ct\\msa\\service\\user.properties";}
		else
		{lin="C:\\Users\\Trainingvdi\\Downloads\\MobileStoreApplication4\\MobileStoreApplication3\\MobileStoreApplication3\\src\\com\\ct\\msa\\service\\admin.properties";}
		
		FileInputStream fis=new FileInputStream(lin); 
	
        prop.load (fis);
  
        if(prop.containsKey(un))
        {
        String pw=prop.getProperty(un);
        if(pwd.equals(pw))
        { isAllowed= true;
        log.info("user is allowed to log in");
        }
        else 
        { isAllowed=false;
        log.info("user is not allowed to log in");}
        }
		}
		catch(IOException e)
		{
			log.error("error occured :: " + e.getMessage());
			throw new BookException("Login Error : login data file not found contact Admin");
		}

        return isAllowed;
        
		
	}
	
	
	

}

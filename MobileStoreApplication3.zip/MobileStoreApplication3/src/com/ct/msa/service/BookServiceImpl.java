package com.ct.msa.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import com.ct.msa.dao.BookDaoImpl;
import com.ct.msa.exception.BookException;
import com.ct.msa.model.Book;

public class BookServiceImpl implements IBookService {
	
	
	ArrayList<Book>bl=new ArrayList<Book>();
	static HashMap<Integer,Book> hs=new HashMap<Integer,Book>();
	
	boolean bn=false;
	boolean id=false;
	ResultSet st=null;
	boolean qs;
	Properties prop=new Properties (); 
	String lin;
	@Override
	public int addBook(Book m) throws BookException{
		return new BookDaoImpl().addBook(m);

	
	}

	@Override
	public int deleteBook(int mId) throws BookException {

		return new BookDaoImpl().deleteBook(mId);
		
		

	}

	/*@Override
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		do {
		new MobileDaoImpl().updateMobileDetails(mId);
	}while(mId>99 && mId<1000);

	}*/

	@Override
	public Book searchBookById(int mId) throws BookException {
		Book m1=new Book();
	
		m1=new BookDaoImpl().searchBookById(mId);
		
		return m1;
	}

	@Override
	public ArrayList<Book> displayAllBooks() throws BookException {
		// TODO Auto-generated method stub
	//	ArrayList<Mobile> m1=new ArrayList<Mobile>();
		bl=new BookDaoImpl().displayAllBooks();
		return bl;
	}

	public boolean login(String un,String pwd,int lg) throws BookException {
		try
		{
		if(lg==1)
		{lin="C:\\Users\\Trainingvdi\\MobileStoreApplication3\\src\\com\\ct\\msa\\service\\user.properties";}
		else
		{lin="C:\\Users\\Trainingvdi\\MobileStoreApplication3\\src\\com\\ct\\msa\\service\\admin.properties";}
		
		FileInputStream fis=new FileInputStream(lin); 
	
        prop.load (fis);
   
        if(prop.containsKey(un))
        {
        String pw=prop.getProperty(un);
        if(pwd.equals(pw))
        { bn= true;}
        else 
        { bn=false;}
        }
		}
		catch(IOException e)
		{
			throw new BookException("Login Error");
		}

        return bn;
        
		
	}
	
	
	

}

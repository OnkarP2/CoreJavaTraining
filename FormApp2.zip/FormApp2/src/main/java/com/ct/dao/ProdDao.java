package com.ct.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ct.model.Product;


@Repository
public class ProdDao {
		
	Product pr=null;
	List<Product> al=new ArrayList<Product>();
	@Autowired
	private JdbcTemplate jdbcTemplate;  
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	  
	public String saveProduct(Product product)
	{
		
		pr=product;
		SessionFactory sessionFactory;
		Configuration configuration = new Configuration().configure();
        ServiceRegistry serviceRegistry= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
         // builds a session factory from the service registry
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);  
        Session session =sessionFactory.openSession();
        session.beginTransaction();
	
        session.save(pr);
       // Product product = (Product)session.load(com.ct.hibernate.module.Product.class, 2);
 
		session.getTransaction().commit(); 
		session.close();
	//	getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		 return "data of "+product.getProdName()+" is added";
	}

	
	/*public List<Product> viewAllProduct()
	{
		 String sql = "SELECT * FROM contact";
		    List<Product> listContact = jdbcTemplate.query(sql, new RowMapper<Product>() {
		 
		        @Override
		        public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		            Product aContact = new Product();
		 
		            aContact.setId(rs.getInt("contact_id"));
		            aContact.setName(rs.getString("name"));
		            aContact.setEmail(rs.getString("email"));
		            aContact.setAddress(rs.getString("address"));
		            aContact.setTelephone(rs.getString("telephone"));
		 
		            return aContact;
		        }
		 
		    });
		 
		    return listContact;
	}*/
	
	
	public Product viewProduct(int id)
	{
		Product product=null;
		
		SessionFactory sessionFactory;
		Configuration configuration = new Configuration().configure();
        ServiceRegistry serviceRegistry= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
         // builds a session factory from the service registry
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);  
        Session session =sessionFactory.openSession();
        session.beginTransaction();
	
       // Product product = (Product)session.load(com.ct.hibernate.module.Product.class, 2);
   	 	product = (Product)session.load(com.ct.model.Product.class, id);
   	 	product.getDiscount();
   	 	/*String qry="select * from formproduct p";
   	 	SQLQuery qr=session.createSQLQuery(qry);
   	 	qr.addEntity(Product.class);
   	 	List<Product> l=qr.list();
   	 //	Product p=(Product)qr.uniqueResult();
   	 	System.out.println(l.get(0));
   	 	al.add(product);*/
   	 	/*Criteria crit=session.createCriteria(Product.class);
   	 	Criterion name = Restrictions.eq("prodName","books");
   	 	crit.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);
   	 	List<Product> res=crit.list();
   	 	System.out.println(res);*/
   	 /*	Criteria crit=session.createCriteria("prod");
   	 	List<Product> res=crit.list();*/
   	 	
   	 	
   	 	//Product pr1=product;
		session.getTransaction().commit(); 
	
		session.close();
	//	getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		 return product;
	}
	
	public String deleteProduct(int id)
	{
		Product product=null;
		
		SessionFactory sessionFactory;
		Configuration configuration = new Configuration().configure();
        ServiceRegistry serviceRegistry= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);  
        Session session =sessionFactory.openSession();
        session.beginTransaction();

   	 	product = (Product)session.get(com.ct.model.Product.class, id);
   	 	session.delete(product);
   	 	
   	 	
   	 	//Product pr1=product;
		session.getTransaction().commit(); 
	
		session.close();
		 return "data of "+product.getProdName()+" is deleted";
	}
	
	public List<Product> viewAllProducts()
	{
		Product product=null;
		
		SessionFactory sessionFactory;
		Configuration configuration = new Configuration().configure();
        ServiceRegistry serviceRegistry= new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);  
        Session session =sessionFactory.openSession();
        session.beginTransaction();

        Criteria crit=session.createCriteria(Product.class);
        List<Product> prodList=crit.list();
   	 /*	product = (Product)session.get(com.ct.model.Product.class, id);
   	 	session.delete(product);
   	 	*/
   	 	
   	 	//Product pr1=product;
		session.getTransaction().commit(); 
	
		session.close();
		 return prodList;
	}
	
	
}



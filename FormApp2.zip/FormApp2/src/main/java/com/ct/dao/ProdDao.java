package com.ct.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ct.model.Product;


@Repository
public class ProdDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;  
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	  
	public String saveProduct(Product product)
	{
		getJdbcTemplate().update("insert into product (prodName,price,prodQty,description,discount) values(?,?,?,?,?)",new Object[] {product.getProdName(),product.getPrice(),product.getProdQty(),product.getDescription(),product.getDiscount()});
		 return "data of "+product.getProdName()+" is added";
	}

}



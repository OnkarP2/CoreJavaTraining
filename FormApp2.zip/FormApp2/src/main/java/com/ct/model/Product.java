package com.ct.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Product {
	private int id;
	@Size(min=3, max=16,message="product name cannot be less than 3")
	private String prodName;
	@NotNull(message="field is mandatory")
	private float price;
	@NotNull(message="field is mandatory")
	private int prodQty;
	@NotNull(message="field is mandatory")
	@Size(min=3, max=16,message="product description cannot be less than 3")
	private String description;
	@NotNull(message="field is mandatory")
	private float discount;
	public Product() {
	}
	public Product(String prodName, float price, int prodQty, String description, float discount) {
		super();
		this.prodName = prodName;
		this.price = price;
		this.prodQty = prodQty;
		this.description = description;
		this.discount = discount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getProdQty() {
		return prodQty;
	}
	public void setProdQty(int prodQty) {
		this.prodQty = prodQty;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getDiscount() {
		return discount;
	}
	public void setDiscount(float discount) {
		this.discount = discount;
	}
	
	
	
	
}

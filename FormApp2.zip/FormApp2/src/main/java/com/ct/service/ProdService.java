package com.ct.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.ProdDao;
import com.ct.model.Product;

@Service
public class ProdService {
	
	@Autowired
	private ProdDao dao;
	
	
	public String saveProduct(Product product)
	{
	return dao.saveProduct(product);
	}
}

package com.ct.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.ProdDao;
import com.ct.model.Product;

@Service
public class ProdService {
	
	@Autowired
	private ProdDao dao;
	
	
	public String saveProduct(Product product)
	{
	return dao.saveProduct(product);
	}
	
	public Product viewProduct(int id)
	{
	return dao.viewProduct(id);
	}
	
	public String deleteProduct(int id)
	{
	return dao.deleteProduct(id);
	}
	/*public HashMap<Integer, Product> viewAllProduct()
	{
	return 
	}*/
	
	public List<Product> viewAllProducts()
	{
	return dao.viewAllProducts();
	}
}

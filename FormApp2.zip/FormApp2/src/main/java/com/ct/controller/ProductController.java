package com.ct.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.ct.model.Product;
import com.ct.service.ProdService;
import com.ct.dao.ProdDao;


@Controller
public class ProductController {
	
	@Autowired
	private ProdService prodService;
	
	
	@RequestMapping("/")
	public String getHomePage(){

		return "index";
	}
	
	@RequestMapping(value="/store",method=RequestMethod.POST)
	public String storeProductInDb(@Valid @ModelAttribute("prod") Product product,BindingResult br,Model m){
		if(br.hasErrors()) {
			System.out.println(br);
			return "add";
		}
		else {
			
	        String status=prodService.saveProduct(product);
	        m.addAttribute("msg", status);
		}
		return "add";
	}
	
	
	@RequestMapping("/store")
	public String getStorepage(Model m) {
		Product p=new Product();
		m.addAttribute("prod",p);
		return "add";
	}

}

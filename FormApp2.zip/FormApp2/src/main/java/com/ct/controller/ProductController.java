package com.ct.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Product;
import com.ct.service.ProdService;
import com.ct.dao.ProdDao;


@Controller
public class ProductController {
	static HashMap<Integer, Product> h1= new HashMap<Integer, Product>();
	List<Product>prodList=null;
	Product product=null;
	@Autowired
	private ProdService prodService;
	
	
	@RequestMapping("/")
	public String getHomePage(){

		return "index";
	}
	
	@RequestMapping(value="/store",method=RequestMethod.POST)
	public String storeProductInDb(@Valid @ModelAttribute("prod") Product product,BindingResult br,Model m){
		if(br.hasErrors()) {
			System.out.println(br);
			return "add";
		}
		else {
			
	        String status=prodService.saveProduct(product);
	        System.out.println(product);
	        m.addAttribute("msg", status);
		}
		return "add";
	}
	
	
	@RequestMapping("/store")
	public String getStorepage(Model m) {
		Product p=new Product();
		m.addAttribute("prod",p);
		return "add";
	}

	
	@RequestMapping("/retrieveall")
	public String getAll(HttpServletRequest request) {
//		 h1=prodService.saveProduct();
		prodList=prodService.viewAllProducts();
		request.setAttribute("list", prodList);
		return "retrieveall";
	}
	
	
	
	
	/*@RequestMapping(value="/store",method=RequestMethod.POST)
	public @ResponseBody Product storeProductInDb(@RequestBody @Valid @ModelAttribute("prod") Product product,BindingResult br,Model m){
		if(br.hasErrors()) {
			System.out.println(br);
			System.out.println(product);
			return product;
		}
		else {
			
	        String status=prodService.saveProduct(product);
	    	System.out.println(product);
	        m.addAttribute("msg", status);
		}
		return product;
	}
	*/
	@RequestMapping("/upload")
	public String getUploadPage() {
	
		return "upload";
	}
	@RequestMapping(value="/upload",method=RequestMethod.POST)
	public ModelAndView saveimage( @RequestParam CommonsMultipartFile file,  
	           HttpSession session) throws Exception{  
	  
	    ServletContext context = session.getServletContext();  
	    String path = context.getContextPath();
	    System.out.println(path);//(UPLOAD_DIRECTORY);  
	    String filename = file.getOriginalFilename();  
	    System.out.println("here");
	   
	   // System.out.println(path+" "+filename);        
	  
	    byte[] bytes = file.getBytes();  
	    BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(  
	         new File(path+ File.separator + filename)));  
	    stream.write(bytes);  
	    stream.flush();  
	    stream.close();  
	           
	    return new ModelAndView("upload","filesuccess","File successfully saved!");  
	    }  
	
	@RequestMapping("/searchbyid")
	public String getSearchpage() {
		
		return "getbyid";
	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public String search(@RequestParam ("number") int id,HttpServletRequest request) {
		
		product=prodService.viewProduct(id);
		request.setAttribute("prod",product);
		return "getbyid";
	}
	
	@RequestMapping("/remove")
	public String getRemovepage() {
		
		return "remove";
	}
	
	@RequestMapping(value="/remove",method=RequestMethod.POST)
	public String removeProd(@RequestParam ("number") int id,HttpServletRequest request) {
		
		String msg1=prodService.deleteProduct(id);
		request.setAttribute("msg1",msg1);
		return "remove";
	}
	
	
	
	
	
}
